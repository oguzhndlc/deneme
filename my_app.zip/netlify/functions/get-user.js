const { Client } = require('pg');

exports.handler = async function(event, context) {
  const client = new Client({
    connectionString: process.env.NETLIFY_DATABASE_URL,
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    const result = await client.query('SELECT id, username FROM deneme LIMIT 1');
    await client.end();

    return {
      statusCode: 200,
      body: JSON.stringify(result.rows[0])
    };

  } catch (err) {
    console.error("Veritabanı hatası:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'DB error', details: err.message })
    };
  }
};
